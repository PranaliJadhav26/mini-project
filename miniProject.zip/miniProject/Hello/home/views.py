

from django.shortcuts import render
import urllib.request
import json


# Create your views here.
def index(request):
    if request.method == 'POST':

        city = request.POST['city']
        source = urllib.request.urlopen('http://api.openweathermap.org/data/2.5/weather?q='+city+'&units=metric&appid=6a6f9479d745f5f41f8104ea4ef040c8').read()
        list_of_data = json.loads(source)
        data = {
            'city_name': city,
            'country_code': list_of_data['sys']['country'],
            'temperature': str(list_of_data['main']['temp']) + '°C',
            'description': list_of_data['weather'][0]['description'],
            'icon': list_of_data['weather'][0]['icon']
        }

        print(data)
    else:
        data = {}

    return render(request, 'index.html', data)



       


